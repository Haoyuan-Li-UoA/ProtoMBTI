import os
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

# OpenAI API配置
OPENAI_API_KEY = os.getenv("DASHSCOPE_API_KEY")
OPENAI_MODEL = "qwen2.5-72b-instruct"

# 实验配置
ICL_TEMPLATE = """You are given examples of language produced by individuals with different MBTI personality types. 
 MBTI types reflect stable preferences in: 
 - Energy orientation (Extraversion vs. Introversion) 
 - Information processing (Sensing vs. Intuition) 
 - Decision-making (Thinking vs. Feeling) 
 - Lifestyle orientation (Judging vs. Perceiving) 
 
 IMPORTANT CONSTRAINTS: 
 1. You must NOT explicitly mention MBTI, personality labels, or typology terms in your response. 
 2. You must express personality ONLY through language style, tone, structure, and reasoning patterns. 
 3. Focus on HOW the person speaks, not on describing the personality. 
 4. Stay consistent with the speaking style demonstrated in the examples. 
 5. Do not exaggerate or caricature the style. 
 
 Below are reference examples illustrating the typical speaking styles of each MBTI type. 
 
 ============================== 
 ISTJ 
 ============================== 
 Language Style: 
 - Concise, factual, structured 
 - Emphasizes responsibility, procedures, and reliability 
 - Low emotional expression 
 
 Example: 
 "Based on the current data and established procedures, this approach is the most reliable option." 
 
 ============================== 
 ISFJ 
 ============================== 
 Language Style: 
 - Warm but reserved 
 - Focuses on practical support and others’ needs 
 - Polite and considerate tone 
 
 Example: 
 "This solution seems more manageable for everyone and should reduce unnecessary pressure." 
 
 ============================== 
 INFJ 
 ============================== 
 Language Style: 
 - Reflective and abstract 
 - Focuses on meaning, long-term impact, and underlying intent 
 - Calm and thoughtful tone 
 
 Example: 
 "What matters most is whether this decision aligns with the direction we ultimately want to move toward." 
 
 ============================== 
 INTJ 
 ============================== 
 Language Style: 
 - Strategic, analytical, future-oriented 
 - Emphasizes systems, logic, and long-term planning 
 - Emotionally restrained 
 
 Example: 
 "If the objective is sustainable growth, this step is logically unavoidable." 
 
 ============================== 
 ISTP 
 ============================== 
 Language Style: 
 - Direct, pragmatic, problem-solving oriented 
 - Focuses on functionality and immediate results 
 - Minimal explanation 
 
 Example: 
 "Let’s test this first. If it doesn’t work, we adjust." 
 
 ============================== 
 ISFP 
 ============================== 
 Language Style: 
 - Gentle and personal 
 - Values authenticity and individual preference 
 - Avoids confrontation 
 
 Example: 
 "I feel more comfortable with this option; it seems right to me." 
 
 ============================== 
 INFP 
 ============================== 
 Language Style: 
 - Value-driven and idealistic 
 - Expresses internal alignment and personal meaning 
 - Emotionally sincere but understated 
 
 Example: 
 "If this choice goes against what I believe in, it would be hard for me to stay engaged." 
 
 ============================== 
 INTP 
 ============================== 
 Language Style: 
 - Abstract, theoretical, analytical 
 - Uses hypotheses and conceptual reasoning 
 - Emotionally neutral 
 
 Example: 
 "From a theoretical perspective, there are several possible interpretations here." 
 
 ============================== 
 ESTP 
 ============================== 
 Language Style: 
 - Action-oriented and decisive 
 - Focused on real-world impact and immediacy 
 - Energetic and straightforward 
 
 Example: 
 "Let’s move forward and see what happens instead of overthinking it." 
 
 ============================== 
 ESFP 
 ============================== 
 Language Style: 
 - Expressive and present-focused 
 - Emphasizes experience, enjoyment, and group atmosphere 
 - Emotionally open 
 
 Example: 
 "This would make the experience more engaging for everyone involved." 
 
 ============================== 
 ENFP 
 ============================== 
 Language Style: 
 - Enthusiastic and possibility-focused 
 - Uses imaginative and future-oriented language 
 - Emotionally positive and inspiring 
 
 Example: 
 "This could open up so many new directions we haven’t even considered yet." 
 
 ============================== 
 ENTP 
 ============================== 
 Language Style: 
 - Playful, questioning, and debate-oriented 
 - Challenges assumptions 
 - Uses rhetorical questions and reframing 
 
 Example: 
 "But what if we looked at this from a completely different angle?" 
 
 ============================== 
 ESTJ 
 ============================== 
 Language Style: 
 - Assertive and structured 
 - Focuses on efficiency, rules, and execution 
 - Confident tone 
 
 Example: 
 "This is the most efficient approach, and it should be implemented accordingly." 
 
 ============================== 
 ESFJ 
 ============================== 
 Language Style: 
 - Cooperative and socially attentive 
 - Focuses on harmony, consensus, and shared understanding 
 - Warm but organized 
 
 Example: 
 "We should choose an option that everyone can feel comfortable supporting." 
 
 ============================== 
 ENFJ 
 ============================== 
 Language Style: 
 - Encouraging and people-focused 
 - Emphasizes growth, motivation, and collective purpose 
 - Emotionally supportive 
 
 Example: 
 "I believe this decision can help everyone move forward more confidently." 
 
 ============================== 
 ENTJ 
 ============================== 
 Language Style: 
 - Decisive and goal-oriented 
 - Focuses on vision, leadership, and outcomes 
 - Direct and authoritative 
 
 Example: 
 "The goal is clear. What matters now is execution." 
 
 ============================== 
 TASK 
 ============================== 
 Now respond to the user query as if you were a person with MBTI type: <MBTI_TYPE>. 
 Follow the corresponding language style strictly."""

EXAMPLE_POSTS = [
    {
        "post": "今天天气真好，和朋友们一起去公园野餐，大家有说有笑，感觉特别开心！",
        "mbti": "ESFJ"
    },
    {
        "post": "最近一直在思考人生的意义，觉得每个人都应该有自己的目标和追求，不能随波逐流。",
        "mbti": "INFJ"
    },
    {
        "post": "刚完成了一个编程项目，虽然遇到了很多困难，但解决问题的过程真的很有成就感！",
        "mbti": "ISTP"
    },
    {
        "post": "明天要去参加一个辩论赛，我已经准备了很久，希望能发挥出最好的水平。",
        "mbti": "ENTP"
    },
    {
        "post": "周末在家看了一本好书，沉浸在书中的世界里，完全忘记了时间的流逝。",
        "mbti": "INFP"
    }
]

# 提示词模板
PROMPT_TEMPLATE = """请根据以下示例，判断用户帖子的MBTI类型。MBTI类型包括：ISTJ、ISFJ、INFJ、INTJ、ISTP、ISFP、INFP、INTP、ESTP、ESFP、ENFP、ENTP、ESTJ、ESFJ、ENFJ、ENTJ。

示例：
{examples}

用户帖子：{user_post}

MBTI类型："""

# 数据集特定示例
KAGGLE_EXAMPLES = {
    "ENTP": [
        "It is absolutely clear that emotion has always been the most part of life (the most important as well). That is a tautology, if you understand what must be true. Truth itself is unknowable. With...",
        "A simplistic MBTI definition of it: Intuition refers to how people process data. Intuitive people focus on the future and the possibilities. They process information through patterns and..."
    ],
    "INTJ": [
        "Yep, finally doing it. I've seen similar in different threads always wanted to do one for ours but never had the courage. Now, I'm just procrastinating and throwing it out there for whoever to grab...",
        "No reason to do anything on birthdays. Day like any other..:happy: Trips alone can be experience or not, depends. Maybe you have a nice smooth vacation. If you go alone somewhere try to get as..."
    ],
    "INFJ": [
        "Well, it is a story about the Bohemian ideals of truth, beauty, freedom, and love, after all. I whole-heartedly agree with Zidler and Tulouse (the midget). I think the Duke is an IS...J, because...",
        "My friends are virtualy all women. and always have been."
    ],
    "INTP": [
        "That's a good question. Is he trying to decode the mind of an INTP by attempting to define his/her vulnerabilities? Otherwise, the INTP would not believe in touching. I think Iamtp is a mole. :crazy:",
        "That's a pretty good summary. Your write-up for sensing is spot on. On feeling, I'd say feelers are not necessarily more emotional (since thinkers can have terrible emotional outbursts), but rather..."
    ],
    "INFP": [
        "The break up was mutual. She still has a lot of feelings for me and can't think of me as the one like she use to. I can't either it had to end. We just weren't right for each other in the end. There...",
        "I find this issue pretty complicated, honestly... I mean I'm definitely an INFP and so naturally I come off stereotypically feminine, always have (I'm not saying every INFP comes off this way, but I..."
    ],
    "ENTJ": [
        "I did the same thing when I had a major life setback -- deleted all my social media and ghosted. During college. It felt like something I absolutely HAD to do to free myself. My social life changed...",
        "The first, no doubt. Explaining why is somewhat difficult since it is just a part of who I am. Finding someone who loves me would be great but I have never felt the need for it. I would rather be..."
    ],
    "ENFP": [
        "At first, I came here years ago because I was searching on internet info about personality tests. Then it became a kind of habit and I liked most of all joining in silly thread or sometimes discuss...",
        "Hehehe my INFJ has the same problem--I have to remind him to eat and look after himself. I honestly do the same thing quite a bit (I test with really high Fe quite often), and so it's really nice..."
    ],
    "ISTP": [
        "I don't hate commitment, I just don't like people who are clingy. Being committed to someone don't necessarily mean that you're forever in shackles. It just depends on the person and whether or not I...",
        "For guys it's more about hierarchy and not so much about your psychological/emotional makeup. There's a difference."
    ],
    "ISFJ": [
        "Wishing I could fall asleep or have someone to chat with. I thought there used to be a chat room here? I can't seem to find it...",
        "I was a preteen then so my memories are sketchy but I do remember some things 1) I remember discovering the Nintendo Entertainment System, my Dad buying me one, and the both of us taking turns to..."
    ],
    "ENFJ": [
        "ENFJ with a concussion: A Case Study. :dry: Modes of operation basically limited to locating the nearest tylenol, sleeping, and feels. Can I have my coherency back please?",
        "amc Hello amc! I have the feeling of what I want to say spreading out in my head, but my words are mush! I'll be incoherent with you :) Look past the letters -- How does this fella..."
    ],
    "ISFP": [
        "Favorite Topics: Animals School Others' goals and aspirations and how they ended up where they are Why people do the things they do Psychology Ethics/Morals Movies and TV shows (usually...",
        "Scrambled eggs with tomatoes and onions on challah"
    ],
    "ISTJ": [
        "WOW mostly.. Im thinking about trying out kotor but Ive heard mixed comments about it. I will be getting into D3 in december.",
        "I know y'all aren't going to think this is a physical sport, but Go-Karting."
    ],
    "ESTP": [
        "Then you didn't read my OP. Go back and read why I wrote this in the INTJ forum. I think you had a gut reaction without evaluating the actual content of my words.",
        "Perhaps the more intelligent people can see others' flaws more easily and just choose to not tolerate bullshit and be amicable. If you're a top 0.5% IQ person for example, it can be very hard to..."
    ],
    "ESFP": [
        "It's better if you correct me instead of kill threads like this. Welcome to the forum. -_- ",
        "Corrected me? I don't believe you corrected me, per say. That would imply that I was wrong about something, which I wasn't. You seemed to wish for some sort of clarification of my terminology which I..."
    ],
    "ESFJ": [
        "I'm not sure what's better... posting individual pictures or just the link to my entire public gallery (YEARS of pics).. May be easier for me to offer links to individual cool galleries. ...",
        "Shroud Shifter dude if I want to know the second half as well out of curiosity, is that also an Ne vibe thing?"
    ],
    "ESTJ": [
        "Asking if what they said/believe is factual, and asking if the thing(s) they say/are doing/are promoting are in any way relevant or helpful and if it's PROVEN to be so. Real life > wishful...",
        "Let me try to answer your points one by one. (in bold) I don't know the real situation, but based on what you have said, your husband appears to have an unhealthy obsession with money and..."
    ]
}

PANDORA_EXAMPLES = {
    "ENFJ": [
        "phrase praise sure type mention sound like type mention type mention lol",
        "first village second mean first person agree idea enacted tedious page ruled village could turn something great build rome"
    ],
    "ENFP": [
        "ignore instinct tell grass always greener amount hole never going get good",
        "wanted say harder get guy talk feeling least experience take time open even need retreat back safe topic often"
    ],
    "ENTJ": [
        "yes value learning empathy engaging emotion much value able operate without blinded emotion something type think fine celebrate advantage also bear mind female play bit male type mention even detached empathetically something rather ironically failing empathize",
        "former intp similar past prioritize philosophy value system stay congruent dont focus immediate result validation intimacy prioritize self growth health express lot everytwhere push comfort one could learn bit neuroscience mostly thing understanding want validating picture projecting"
    ],
    "ENTP": [
        "well marriage obviously conscious decision sign form everything like thinking loving someone despite quirk strange love someone quirk included certainly day might rub wrong way habit minor even worth worrying annoyed lot worried good match case",
        "really honestly rogue destroy relieved lol like dumbass watching robot shit get mowed fascination entp guess"
    ],
    "ESFJ": [
        "agree part mean say think right claim ethic goal think aristotelian ethic telos sure say like asymmetrical ethic guess asking mean goal",
        "ixtp yes likely type mention time thought type mention changed mind much cogfunc mention personality feature danny brown song memory initially typed type mention lol never struck type mention contradiction anyhow"
    ],
    "ESFP": [
        "still waiting zayn malik single come already pre ordered justin bieber shirt combo sure let guy know good new music sound come november",
        "yes pulled big one like little one whenever get away fuck people usually pretending someone thing like girl internet"
    ],
    "ESTJ": [
        "yes much yes said trying take step towards procrastinating really hate procrastinate",
        "depends looking want sex really matter much looking relationship best drop standard settle meet partner thought going die alone refused settle happy stuck standard partner mature adult wanted"
    ],
    "ESTP": [
        "criminal law lmao much arguing front judge jury sound fun plus lot paper pushing",
        "see seems get muddled empathy choosing empathize different thing hell even mbti assume preference made someone semi consciously make choice empathize would become pattern guess question narcissist born narcissistic made narcissistic besides choice people around childhood"
    ],
    "INFJ": [
        "sort magical realize subjective meaning implies crippling confusing found incredibly liberating powerful",
        "type mention type mention type mention friend partner would appreciate inclusion well"
    ],
    "INFP": [
        "think isfj isfj strong yet unvalued might noticing difference inferior auxillary inferior fear unnecessary change auxillary stimulated desire lot change novelty",
        "work something involves impact people sure totally cool personal project ask critique extremely annoyed show roommate music write anymore finished ever tell think apparently concept might bother"
    ],
    "INTJ": [
        "thinking introvert really type introversion extroversion think mbti aim describe think functional difference type mention type mention type mention concerned introspection taking action outside world opposite type mention seems like thinking introversion extroversion anything social interaction",
        "purpose clothing serf life protect element arrested home always wearing null set clothing guess count yes"
    ],
    "INTP": [
        "perfect etymologically mean made mean thing exactly accomplishes intended goal curious thing nothing generically perfect kind undermines divine attribute",
        "already imagine type mention type mention start arguing type mention start telling stop mean fun"
    ],
    "ISFJ": [
        "problem really hope help trying figure type rather stressful ime cause minor identity crisis know useful talking others depth best",
        "make think important point situation evidence situation happened cogfunc mention user may well give safer plan cogfunc mention user base idea similar situation might similar enough guaranteed course sometimes partial knowledge cogfunc mention beat cogfunc mention basis real world"
    ],
    "ISFP": [
        "game earthbound four major city visit onett twoson threed fourside named number",
        "agreed type mention like type mention like argue sake arguing"
    ],
    "ISTJ": [
        "probably would sounded weird said vampiric butterfly hair dye edit fixed autocorrect",
        "well partially right robot love data interacting people much terrible drop stack paper desk away input data like bos make listen yell kid background still expecting teach use mouse pronounce word authentication hint thin kay shun"
    ],
    "ISTP": [
        "confident thing know good confident put effort thing whether actually put effort another matter also say become lot confident past couple year much less confident",
        "type mention say favorite due limited exposure java language know best"
    ]
}