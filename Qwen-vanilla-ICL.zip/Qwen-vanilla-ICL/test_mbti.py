import unittest
from unittest.mock import patch, MagicMock
import openai
import config
from mbti_icl import prepare_examples, predict_mbti

class TestMBTIICL(unittest.TestCase):
    
    def test_prepare_examples(self):
        """测试示例准备函数"""
        examples = prepare_examples()
        self.assertIn("帖子：", examples)
        self.assertIn("MBTI：", examples)
        self.assertIn("ESFJ", examples)
        self.assertIn("INFJ", examples)
    
    @patch('openai.ChatCompletion.create')
    def test_predict_mbti(self, mock_create):
        """测试MBTI预测功能"""
        # 设置mock响应
        mock_response = MagicMock()
        mock_response.choices[0].message.content.strip.return_value = "ENFP"
        mock_create.return_value = mock_response
        
        # 测试预测功能
        post_content = "我喜欢尝试新事物，和不同的人交流，充满好奇心！"
        result = predict_mbti(post_content)
        
        # 验证结果
        self.assertEqual(result, "ENFP")
        mock_create.assert_called_once()
    
    @patch('openai.ChatCompletion.create')
    def test_predict_mbti_api_failure(self, mock_create):
        """测试API调用失败时的处理"""
        # 设置mock抛出异常
        mock_create.side_effect = Exception("API调用失败")
        
        # 测试预测功能
        post_content = "测试帖子"
        result = predict_mbti(post_content)
        
        # 验证结果
        self.assertIsNone(result)

if __name__ == '__main__':
    unittest.main()