import os
import json
import time
from dotenv import load_dotenv
import dashscope
from config import ICL_TEMPLATE, KAGGLE_EXAMPLES, PANDORA_EXAMPLES

load_dotenv()

# 配置Qwen API
def configure_qwen_api():
    api_key = os.getenv("DASHSCOPE_API_KEY")
    if not api_key:
        raise RuntimeError("DASHSCOPE_API_KEY 未设置")
    
    dashscope.api_key = api_key
    # 新加坡/国际站点：必须切 intl endpoint（否则会 401 InvalidApiKey）
    dashscope.base_http_api_url = "https://dashscope-intl.aliyuncs.com/api/v1"
    print("Qwen API 配置完成")

# 加载采样数据
def load_sampled_data(dataset_name):
    sample_file = f"{dataset_name}_sampled.json"
    if os.path.exists(sample_file):
        with open(sample_file, 'r', encoding='utf-8') as f:
            sampled_data = json.load(f)
        print(f"已加载保存的采样数据: {sample_file}")
        return sampled_data
    else:
        raise FileNotFoundError(f"采样数据文件不存在: {sample_file}")

# 保存当前处理进度
def save_progress(dataset_name, processed_data, index):
    progress_file = f"{dataset_name}_icl_progress.json"
    progress = {
        "index": index,
        "processed_data": processed_data
    }
    with open(progress_file, 'w', encoding='utf-8') as f:
        json.dump(progress, f, indent=4, ensure_ascii=False)
    print(f"进度已保存到 {progress_file}")

# 加载保存的进度
def load_progress(dataset_name):
    progress_file = f"{dataset_name}_icl_progress.json"
    if os.path.exists(progress_file):
        with open(progress_file, 'r', encoding='utf-8') as f:
            progress = json.load(f)
        print(f"已加载保存的进度: {progress_file}")
        return progress
    return None

# 保存结果
def save_results(results):
    with open("mbti_icl_results.json", 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=4, ensure_ascii=False)
    print("结果已保存到 mbti_icl_results.json")

# 加载结果
def load_results():
    if os.path.exists("mbti_icl_results.json"):
        with open("mbti_icl_results.json", 'r', encoding='utf-8') as f:
            results = json.load(f)
        print("已加载保存的结果")
        return results
    return {}

# 使用ICL预测MBTI类型
def predict_mbti_icl(text, dataset_name):
    # 为所有MBTI类型生成ICL响应
    mbti_types = ["ISTJ", "ISFJ", "INFJ", "INTJ", "ISTP", "ISFP", "INFP", "INTP", 
                 "ESTP", "ESFP", "ENFP", "ENTP", "ESTJ", "ESFJ", "ENFJ", "ENTJ"]
    
    predictions = {}
    
    # 根据数据集名称选择相应的示例
    if dataset_name == "kaggle":
        dataset_examples = KAGGLE_EXAMPLES
    elif dataset_name == "pandora_clean":
        dataset_examples = PANDORA_EXAMPLES
    else:
        dataset_examples = KAGGLE_EXAMPLES  # 默认使用kaggle示例
    
    for mbti_type in mbti_types:
        # 使用ICL模板生成提示词
        prompt = ICL_TEMPLATE.replace("<MBTI_TYPE>", mbti_type) + f"\n\nUser query: {text}"
        
        try:
            resp = dashscope.Generation.call(
                model="qwen2.5-72b-instruct",
                prompt=prompt,
                result_format="text"
            )
            
            if resp.status_code == 200 and resp.output.text:
                predictions[mbti_type] = resp.output.text.strip()
            else:
                print(f"API调用失败 ({mbti_type}): {resp}")
                predictions[mbti_type] = ""
        except Exception as e:
            print(f"调用Qwen API时发生错误 ({mbti_type}): {e}")
            predictions[mbti_type] = ""
    
    return predictions

# 分析ICL响应，找出最匹配的MBTI类型
def analyze_icl_responses(original_text, responses):
    # 这里使用简单的文本相似度分析，实际可以使用更复杂的算法
    # 计算每个响应与原始文本的相似度
    import difflib
    
    similarities = {}
    for mbti_type, response in responses.items():
        if not response:
            similarities[mbti_type] = 0
            continue
        
        # 计算相似度
        similarity = difflib.SequenceMatcher(None, original_text, response).ratio()
        similarities[mbti_type] = similarity
    
    # 找出相似度最高的MBTI类型
    best_match = max(similarities.items(), key=lambda x: x[1])
    return best_match[0], similarities

# 计算每个维度的accuracy
def calculate_accuracy(predictions, ground_truths):
    dimension_correct = {
        "E/I": 0,
        "S/N": 0, 
        "T/F": 0,
        "J/P": 0
    }
    
    total = len(predictions)
    
    for pred, gt in zip(predictions, ground_truths):
        # 验证预测结果是否有效
        if len(pred) != 4:
            continue
        
        # 计算准确率
        if pred[0] == gt["E/I"]:
            dimension_correct["E/I"] += 1
        if pred[1] == gt["S/N"]:
            dimension_correct["S/N"] += 1
        if pred[2] == gt["T/F"]:
            dimension_correct["T/F"] += 1
        if pred[3] == gt["J/P"]:
            dimension_correct["J/P"] += 1
    
    # 计算各维度准确率
    accuracy = {}
    for dimension, correct in dimension_correct.items():
        accuracy[dimension] = correct / total if total > 0 else 0
    
    return accuracy

# 处理单个数据集
def process_dataset(dataset_name, continue_process=True):
    print(f"\n=== 使用ICL处理数据集 {dataset_name} ===")
    
    # 加载采样数据
    sampled_data = load_sampled_data(dataset_name)
    print(f"采样数量: {len(sampled_data)}")
    
    # 加载已保存的进度
    progress = load_progress(dataset_name) if continue_process else None
    start_index = progress["index"] + 1 if progress else 0
    processed_data = progress["processed_data"] if progress else []
    
    # 准备预测和真实值
    predictions = []
    ground_truths = []
    
    # 先添加已处理的数据
    for item in processed_data:
        if item.get("status") == "success":
            predictions.append(item["predicted_mbti"])
            ground_truths.append(item["ground_truth"])
    
    # 调用Qwen模型进行ICL预测
    for i in range(start_index, len(sampled_data)):
        item = sampled_data[i]
        print(f"\n处理第 {i+1}/{len(sampled_data)} 条数据")
        
        # 获取文本内容
        text = item.get("cleaned_post", "") or item.get("post", "")
        if not text:
            # 保存进度（跳过无效数据）
            processed_data.append({
                "item": item,
                "status": "skipped",
                "reason": "no_text"
            })
            save_progress(dataset_name, processed_data, i)
            continue
        
        # 使用ICL预测所有MBTI类型的响应
        print(f"正在为所有MBTI类型生成ICL响应...")
        responses = predict_mbti_icl(text, dataset_name)
        
        # 分析响应，找出最匹配的MBTI类型
        predicted_mbti, similarities = analyze_icl_responses(text, responses)
        
        # 获取真实MBTI维度
        actual_mbti = item["mbti"]
        gt = {
            "E/I": actual_mbti[0],
            "S/N": actual_mbti[1],
            "T/F": actual_mbti[2],
            "J/P": actual_mbti[3]
        }
        
        # 保存处理结果
        processed_data.append({
            "item": item,
            "status": "success",
            "predicted_mbti": predicted_mbti,
            "ground_truth": gt,
            "similarities": similarities,
            "responses": responses
        })
        
        # 更新预测和真实值列表
        predictions.append(predicted_mbti)
        ground_truths.append(gt)
        
        # 打印预测结果
        print(f"真实MBTI: {actual_mbti}")
        print(f"ICL预测MBTI: {predicted_mbti}")
        print(f"相似度最高的前3个类型:")
        sorted_similarities = sorted(similarities.items(), key=lambda x: x[1], reverse=True)[:3]
        for mbti, sim in sorted_similarities:
            print(f"  {mbti}: {sim:.4f}")
        
        # 保存进度
        save_progress(dataset_name, processed_data, i)
        
        # 避免API调用过于频繁
        time.sleep(5)  # ICL需要调用16次API，所以间隔更长
    
    # 计算准确率
    if predictions and ground_truths:
        accuracy = calculate_accuracy(predictions, ground_truths)
        print(f"\n=== 数据集 {dataset_name} 的ICL预测准确率结果 ===")
        for dimension, acc in accuracy.items():
            print(f"  {dimension}: {acc:.4f} ({int(acc*100)}%)")
        
        # 清理进度文件
        progress_file = f"{dataset_name}_icl_progress.json"
        if os.path.exists(progress_file):
            os.remove(progress_file)
            print(f"已删除进度文件: {progress_file}")
        
        return accuracy
    else:
        print(f"\n警告: 数据集 {dataset_name} 没有足够的有效预测结果")
        return None

# 主函数
def main():
    # 配置Qwen API
    configure_qwen_api()
    
    # 加载已保存的结果
    results = load_results()
    
    # 定义数据集
    datasets = ["pandora_clean", "kaggle"]
    
    # 处理每个数据集
    for dataset_name in datasets:
        # 如果已经处理过该数据集，跳过
        if dataset_name in results:
            print(f"\n数据集 {dataset_name} 已经处理过，结果如下:")
            for dimension, acc in results[dataset_name].items():
                print(f"  {dimension}: {acc:.4f} ({int(acc*100)}%)")
            continue
        
        try:
            accuracy = process_dataset(dataset_name)
            if accuracy:
                results[dataset_name] = accuracy
                # 保存结果
                save_results(results)
        except FileNotFoundError as e:
            print(f"\n错误: {e}")
            print(f"请先运行 mbti_qwen_accuracy.py 生成采样数据")
        except Exception as e:
            print(f"\n处理数据集 {dataset_name} 时发生错误: {e}")
            import traceback
            traceback.print_exc()
    
    # 生成最终报告
    print(f"\n=== ICL MBTI预测最终准确率报告 ===")
    for dataset_name, accuracy in results.items():
        print(f"\n{dataset_name} 数据集:")
        for dimension, acc in accuracy.items():
            print(f"  {dimension}: {acc:.4f} ({int(acc*100)}%)")

if __name__ == "__main__":
    main()