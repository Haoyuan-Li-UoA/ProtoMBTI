import os
from dotenv import load_dotenv
import dashscope

load_dotenv()

def main():
    api_key = os.getenv("DASHSCOPE_API_KEY")
    print("DEBUG | DASHSCOPE_API_KEY =", api_key)
    if not api_key:
        raise RuntimeError("DASHSCOPE_API_KEY 未设置")

    dashscope.api_key = api_key

    # 新加坡/国际站点：必须切 intl endpoint（否则会 401 InvalidApiKey）
    dashscope.base_http_api_url = "https://dashscope-intl.aliyuncs.com/api/v1"  # :contentReference[oaicite:1]{index=1}

    resp = dashscope.Generation.call(
        model="qwen2.5-72b-instruct",
        prompt="你好，请简单介绍一下你自己",
    )
    print(resp)

if __name__ == "__main__":
    main()
