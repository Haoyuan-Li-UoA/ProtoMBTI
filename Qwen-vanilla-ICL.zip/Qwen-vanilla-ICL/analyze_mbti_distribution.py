import json
import collections
import os

def analyze_mbti_distribution(json_file_path):
    # 读取JSON文件
    with open(json_file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # 统计MBTI类型分布
    mbti_counter = collections.Counter()
    dimension_counters = {
        "E/I": collections.Counter(),
        "S/N": collections.Counter(), 
        "T/F": collections.Counter(),
        "J/P": collections.Counter()
    }
    
    for item in data:
        mbti = item.get("mbti", "")
        if len(mbti) != 4:
            continue
        
        mbti_counter[mbti] += 1
        dimension_counters["E/I"][mbti[0]] += 1
        dimension_counters["S/N"][mbti[1]] += 1
        dimension_counters["T/F"][mbti[2]] += 1
        dimension_counters["J/P"][mbti[3]] += 1
    
    # 打印结果
    print(f"数据集 '{json_file_path}' 的分析结果：")
    print(f"总记录数：{len(data)}")
    print(f"有效MBTI记录数：{sum(mbti_counter.values())}")
    print(f"\nMBTI类型分布（前20个）：")
    for mbti, count in mbti_counter.most_common(20):
        print(f"  {mbti}: {count}")
    
    print(f"\n各维度分布：")
    for dimension, counter in dimension_counters.items():
        print(f"  {dimension}:")
        for type_, count in counter.items():
            print(f"    {type_}: {count}")
    
    return mbti_counter, dimension_counters

if __name__ == "__main__":
    # 分析两个数据集
    datasets = ["pandora_cleaned.json", "mbti_dataset_cleaned.json"]
    
    for dataset in datasets:
        if not os.path.exists(dataset):
            print(f"错误：数据集 '{dataset}' 不存在")
            continue
        
        analyze_mbti_distribution(dataset)
        print("=" * 50)
