import kagglehub
import os
import pandas as pd
from data_processor import save_csv_data

def download_mbti_dataset():
    """下载MBTI数据集"""
    print("开始下载MBTI数据集...")
    
    try:
        # 下载数据集
        path = kagglehub.dataset_download("datasnaek/mbti-type")
        print(f"数据集下载完成，路径：{path}")
        
        # 查看下载的文件
        files = os.listdir(path)
        print(f"下载的文件：{files}")
        
        return path, files
        
    except Exception as e:
        print(f"下载数据集失败：{e}")
        print("请确保您已经安装了kagglehub，并且有有效的Kaggle API凭据")
        print("您可以通过访问 https://www.kaggle.com/settings/account 创建API令牌")
        return None, None

def explore_dataset(dataset_path, files):
    """探索数据集结构"""
    if not dataset_path or not files:
        return None
    
    # 找到CSV文件
    csv_files = [f for f in files if f.endswith('.csv')]
    if not csv_files:
        print("未找到CSV文件")
        return None
    
    # 读取第一个CSV文件
    csv_path = os.path.join(dataset_path, csv_files[0])
    print(f"正在读取CSV文件：{csv_path}")
    
    try:
        data = pd.read_csv(csv_path)
        print(f"数据行数：{len(data)}")
        print(f"数据列名：{list(data.columns)}")
        print("\n数据前5行：")
        print(data.head())
        
        # 统计MBTI类型分布
        if 'type' in data.columns:
            print("\nMBTI类型分布：")
            print(data['type'].value_counts())
        
        return data
        
    except Exception as e:
        print(f"读取CSV文件失败：{e}")
        return None

def prepare_dataset_for_icl(data, output_path=None):
    """准备用于ICL的数据集"""
    if data is None:
        return None
    
    # 重命名列以匹配我们的格式
    if 'type' in data.columns and 'posts' in data.columns:
        processed_data = data.rename(columns={
            'type': 'mbti',
            'posts': 'post'
        })
        
        # 清理帖子内容（原始数据中每个用户有多个帖子，用|||分隔）
        processed_data['post'] = processed_data['post'].apply(lambda x: x.split('|||')[0] if '|||' in x else x)
        
        # 只保留需要的列
        processed_data = processed_data[['post', 'mbti']]
        
        # 保存处理后的数据
        if output_path is None:
            output_path = "mbti_dataset_icl.csv"
        
        save_csv_data(processed_data, output_path)
        print(f"\n已准备好用于ICL的数据集：{output_path}")
        return processed_data
    else:
        print("数据格式不符合要求，缺少type或posts列")
        return None

def main():
    """主函数"""
    print("MBTI数据集下载与准备工具")
    print("=" * 50)
    
    # 下载数据集
    dataset_path, files = download_mbti_dataset()
    if not dataset_path:
        return
    
    # 探索数据集
    data = explore_dataset(dataset_path, files)
    if not data is None:
        # 准备用于ICL的数据集
        prepare_dataset_for_icl(data)

if __name__ == "__main__":
    main()