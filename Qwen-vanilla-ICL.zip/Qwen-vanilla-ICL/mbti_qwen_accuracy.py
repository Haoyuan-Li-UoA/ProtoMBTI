import os
import json
import random
import collections
import time
from dotenv import load_dotenv
import dashscope

load_dotenv()

# 配置Qwen API
def configure_qwen_api():
    api_key = os.getenv("DASHSCOPE_API_KEY")
    if not api_key:
        raise RuntimeError("DASHSCOPE_API_KEY 未设置")
    
    dashscope.api_key = api_key
    # 新加坡/国际站点：必须切 intl endpoint（否则会 401 InvalidApiKey）
    dashscope.base_http_api_url = "https://dashscope-intl.aliyuncs.com/api/v1"
    print("Qwen API 配置完成")

# 保存采样数据
def save_sampled_data(sampled_data, dataset_name):
    sample_file = f"{dataset_name}_sampled.json"
    with open(sample_file, 'w', encoding='utf-8') as f:
        json.dump(sampled_data, f, indent=4, ensure_ascii=False)
    print(f"采样数据已保存到 {sample_file}")
    return sample_file

# 加载采样数据
def load_sampled_data(dataset_name):
    sample_file = f"{dataset_name}_sampled.json"
    if os.path.exists(sample_file):
        with open(sample_file, 'r', encoding='utf-8') as f:
            sampled_data = json.load(f)
        print(f"已加载保存的采样数据: {sample_file}")
        return sampled_data
    return None

# 从数据集中采样平衡的数据（大约25%）
def sample_balanced_data(json_file_path, dataset_name, reuse_sample=False):
    # 尝试加载已保存的采样数据
    if reuse_sample:
        sampled_data = load_sampled_data(dataset_name)
        if sampled_data:
            return sampled_data
    
    with open(json_file_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # 过滤出有效MBTI数据
    valid_data = []
    for item in data:
        mbti = item.get("mbti", "")
        if len(mbti) == 4:
            valid_data.append(item)
    
    total_valid = len(valid_data)
    print(f"数据集有效记录数: {total_valid}")
    
    # 计算需要采样的数量（大约25%）
    sample_size = max(1, int(total_valid * 0.25))
    print(f"计划采样数量: {sample_size}")
    
    # 按MBTI类型分组
    mbti_groups = collections.defaultdict(list)
    for item in valid_data:
        mbti = item["mbti"]
        mbti_groups[mbti].append(item)
    
    # 计算每种类型需要采样的数量
    types_count = len(mbti_groups)
    samples_per_type = max(1, sample_size // types_count)
    
    # 采样
    sampled_data = []
    for mbti, items in mbti_groups.items():
        sampled_items = random.sample(items, min(samples_per_type, len(items)))
        sampled_data.extend(sampled_items)
    
    # 确保总样本数不超过sample_size
    if len(sampled_data) > sample_size:
        sampled_data = random.sample(sampled_data, sample_size)
    
    # 验证各维度平衡性
    dimension_counts = {
        "E/I": collections.Counter(),
        "S/N": collections.Counter(), 
        "T/F": collections.Counter(),
        "J/P": collections.Counter()
    }
    
    for item in sampled_data:
        mbti = item["mbti"]
        dimension_counts["E/I"][mbti[0]] += 1
        dimension_counts["S/N"][mbti[1]] += 1
        dimension_counts["T/F"][mbti[2]] += 1
        dimension_counts["J/P"][mbti[3]] += 1
    
    print(f"\n采样后的 {json_file_path} 数据各维度分布：")
    for dimension, counts in dimension_counts.items():
        print(f"  {dimension}: {counts}")
    
    # 保存采样数据
    save_sampled_data(sampled_data, dataset_name)
    
    return sampled_data

# 调用Qwen模型判断MBTI维度
def predict_mbti_dimensions(text):
    prompt = f"You are a professional MBTI personality type analyst. Please analyze the author's MBTI personality type across four dimensions based on the following text content: E/I (Extraversion/Introversion), S/N (Sensing/Intuition), T/F (Thinking/Feeling), J/P (Judging/Perceiving).\n\nText: {text}\n\nPlease output the results in the following format, only output the letters for the four dimensions, no other content:\nE/I: X\nS/N: X\nT/F: X\nJ/P: X"
    
    try:
        resp = dashscope.Generation.call(
            model="qwen2.5-72b-instruct",
            prompt=prompt,
            result_format="text"
        )
        
        if resp.status_code == 200 and resp.output.text:
            return resp.output.text
        else:
            print(f"API调用失败: {resp}")
            return None
    except Exception as e:
        print(f"调用Qwen API时发生错误: {e}")
        return None

# 解析模型输出
def parse_model_output(output):
    if not output:
        return {"E/I": "", "S/N": "", "T/F": "", "J/P": ""}
    
    result = {"E/I": "", "S/N": "", "T/F": "", "J/P": ""}
    
    for line in output.strip().split("\n"):
        line = line.strip()
        if line.startswith("E/I:"):
            result["E/I"] = line.split(":")[1].strip().upper()
        elif line.startswith("S/N:"):
            result["S/N"] = line.split(":")[1].strip().upper()
        elif line.startswith("T/F:"):
            result["T/F"] = line.split(":")[1].strip().upper()
        elif line.startswith("J/P:"):
            result["J/P"] = line.split(":")[1].strip().upper()
    
    return result

# 保存当前处理进度
def save_progress(dataset_name, processed_data, index):
    progress_file = f"{dataset_name}_progress.json"
    progress = {
        "index": index,
        "processed_data": processed_data
    }
    with open(progress_file, 'w', encoding='utf-8') as f:
        json.dump(progress, f, indent=4, ensure_ascii=False)
    print(f"进度已保存到 {progress_file}")

# 加载保存的进度
def load_progress(dataset_name):
    progress_file = f"{dataset_name}_progress.json"
    if os.path.exists(progress_file):
        with open(progress_file, 'r', encoding='utf-8') as f:
            progress = json.load(f)
        print(f"已加载保存的进度: {progress_file}")
        return progress
    return None

# 保存结果
def save_results(results):
    with open("mbti_accuracy_results.json", 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=4, ensure_ascii=False)
    print("结果已保存到 mbti_accuracy_results.json")

# 加载结果
def load_results():
    if os.path.exists("mbti_accuracy_results.json"):
        with open("mbti_accuracy_results.json", 'r', encoding='utf-8') as f:
            results = json.load(f)
        print("已加载保存的结果")
        return results
    return {}

# 计算每个维度的accuracy
def calculate_accuracy(predictions, ground_truths):
    dimension_correct = {
        "E/I": 0,
        "S/N": 0, 
        "T/F": 0,
        "J/P": 0
    }
    
    total = len(predictions)
    
    for pred, gt in zip(predictions, ground_truths):
        # 验证预测结果是否有效
        valid_pred = True
        for dimension, value in pred.items():
            if dimension == "E/I" and value not in ["E", "I"]:
                valid_pred = False
            elif dimension == "S/N" and value not in ["S", "N"]:
                valid_pred = False
            elif dimension == "T/F" and value not in ["T", "F"]:
                valid_pred = False
            elif dimension == "J/P" and value not in ["J", "P"]:
                valid_pred = False
        
        if not valid_pred:
            continue
        
        # 计算准确率
        if pred["E/I"] == gt["E/I"]:
            dimension_correct["E/I"] += 1
        if pred["S/N"] == gt["S/N"]:
            dimension_correct["S/N"] += 1
        if pred["T/F"] == gt["T/F"]:
            dimension_correct["T/F"] += 1
        if pred["J/P"] == gt["J/P"]:
            dimension_correct["J/P"] += 1
    
    # 计算各维度准确率
    accuracy = {}
    for dimension, correct in dimension_correct.items():
        accuracy[dimension] = correct / total if total > 0 else 0
    
    return accuracy

# 处理单个数据集
def process_dataset(json_file_path, dataset_name, reuse_sample=True, continue_process=True):
    print(f"\n=== 处理数据集 {dataset_name} ({json_file_path}) ===")
    
    # 采样平衡数据（大约25%）
    sampled_data = sample_balanced_data(json_file_path, dataset_name, reuse_sample)
    print(f"采样数量: {len(sampled_data)}")
    
    # 加载已保存的进度
    progress = load_progress(dataset_name) if continue_process else None
    start_index = progress["index"] + 1 if progress else 0
    processed_data = progress["processed_data"] if progress else []
    
    # 准备预测和真实值
    predictions = []
    ground_truths = []
    
    # 先添加已处理的数据
    for item in processed_data:
        if item.get("status") == "success":
            predictions.append(item["prediction"])
            ground_truths.append(item["ground_truth"])
    
    # 调用Qwen模型进行预测
    for i in range(start_index, len(sampled_data)):
        item = sampled_data[i]
        print(f"\n处理第 {i+1}/{len(sampled_data)} 条数据")
        
        # 获取文本内容
        text = item.get("cleaned_post", "") or item.get("post", "")
        if not text:
            # 保存进度（跳过无效数据）
            processed_data.append({
                "item": item,
                "status": "skipped",
                "reason": "no_text"
            })
            save_progress(dataset_name, processed_data, i)
            continue
        
        # 调用Qwen模型
        output = predict_mbti_dimensions(text)
        if not output:
            # 保存进度（API调用失败）
            processed_data.append({
                "item": item,
                "status": "failed",
                "reason": "api_error"
            })
            save_progress(dataset_name, processed_data, i)
            continue
        
        # 解析模型输出
        pred = parse_model_output(output)
        predictions.append(pred)
        
        # 获取真实MBTI维度
        mbti = item["mbti"]
        gt = {
            "E/I": mbti[0],
            "S/N": mbti[1],
            "T/F": mbti[2],
            "J/P": mbti[3]
        }
        ground_truths.append(gt)
        
        # 保存处理结果
        processed_data.append({
            "item": item,
            "status": "success",
            "prediction": pred,
            "ground_truth": gt
        })
        
        # 打印预测结果
        print(f"真实MBTI: {mbti}")
        print(f"预测结果:")
        for dimension, value in pred.items():
            print(f"  {dimension}: {value} (真实: {gt[dimension]})")
        
        # 保存进度
        save_progress(dataset_name, processed_data, i)
        
        # 避免API调用过于频繁
        time.sleep(2)
    
    # 计算准确率
    if predictions and ground_truths:
        accuracy = calculate_accuracy(predictions, ground_truths)
        print(f"\n=== 数据集 {dataset_name} 的准确率结果 ===")
        for dimension, acc in accuracy.items():
            print(f"  {dimension}: {acc:.4f} ({int(acc*100)}%)")
        
        # 清理进度文件
        progress_file = f"{dataset_name}_progress.json"
        if os.path.exists(progress_file):
            os.remove(progress_file)
            print(f"已删除进度文件: {progress_file}")
        
        return accuracy
    else:
        print(f"\n警告: 数据集 {dataset_name} 没有足够的有效预测结果")
        return None

# 主函数
def main():
    # 配置Qwen API
    configure_qwen_api()
    
    # 加载已保存的结果
    results = load_results()
    
    # 定义数据集
    datasets = [
        ("pandora_cleaned.json", "pandora_clean"),
        ("mbti_dataset_cleaned.json", "kaggle")
    ]
    
    # 处理每个数据集
    for json_file, dataset_name in datasets:
        # 如果已经处理过该数据集，跳过
        if dataset_name in results:
            print(f"\n数据集 {dataset_name} 已经处理过，结果如下:")
            for dimension, acc in results[dataset_name].items():
                print(f"  {dimension}: {acc:.4f} ({int(acc*100)}%)")
            continue
        
        accuracy = process_dataset(json_file, dataset_name)
        if accuracy:
            results[dataset_name] = accuracy
            # 保存结果
            save_results(results)
    
    # 生成最终报告
    print(f"\n=== 最终准确率报告 ===")
    for dataset_name, accuracy in results.items():
        print(f"\n{dataset_name} 数据集:")
        for dimension, acc in accuracy.items():
            print(f"  {dimension}: {acc:.4f} ({int(acc*100)}%)")

if __name__ == "__main__":
    main()
