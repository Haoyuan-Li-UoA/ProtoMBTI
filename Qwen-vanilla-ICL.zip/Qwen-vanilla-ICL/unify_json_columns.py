import json
import os

def unify_json_columns(input_json_path, output_json_path, target_columns):
    # 读取输入JSON文件
    with open(input_json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # 统一列名和顺序
    unified_data = []
    for item in data:
        unified_item = {
            "post": item.get("posts", ""),
            "mbti": item.get("type", ""),
            "cleaned_post": item.get("posts_cleaned", "")
        }
        unified_data.append(unified_item)
    
    # 写入输出JSON文件
    with open(output_json_path, 'w', encoding='utf-8') as f:
        json.dump(unified_data, f, indent=4, ensure_ascii=False)
    
    print(f"统一完成！JSON文件 '{input_json_path}' 已成功统一为 '{output_json_path}'")
    print(f"共处理了 {len(unified_data)} 条记录")

if __name__ == "__main__":
    # 定义文件路径
    input_file = "pandora_cleaned.json"
    output_file = "pandora_cleaned_unified.json"
    target_columns = ["post", "mbti", "cleaned_post"]
    
    # 检查输入文件是否存在
    if not os.path.exists(input_file):
        print(f"错误：JSON文件 '{input_file}' 不存在")
        exit(1)
    
    # 执行统一操作
    unify_json_columns(input_file, output_file, target_columns)
