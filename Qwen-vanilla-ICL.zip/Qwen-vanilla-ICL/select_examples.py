import json
import random
import collections

def load_json(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def select_examples(data, dataset_name, num_examples=2, min_length=50, max_length=300):
    """为每个MBTI类型从数据中选择指定数量的示例，要求文本长度在指定范围内"""
    # 按MBTI类型分组
    mbti_groups = collections.defaultdict(list)
    for item in data:
        mbti = item.get("mbti", "")
        if len(mbti) != 4:
            continue
        
        # 选择合适长度的文本
        text = item.get("cleaned_post", "") or item.get("post", "")
        if min_length <= len(text) <= max_length:
            mbti_groups[mbti].append({
                "text": text,
                "mbti": mbti
            })
    
    # 为每个类型选择示例
    examples = {}
    for mbti, items in mbti_groups.items():
        if len(items) >= num_examples:
            selected = random.sample(items, num_examples)
            examples[mbti] = selected
        else:
            print(f"{dataset_name}数据集：{mbti}类型的合适示例不足{num_examples}个，实际有{len(items)}个")
            if items:
                examples[mbti] = items
    
    return examples

def main():
    # 加载数据集
    print("正在加载数据集...")
    
    # Kaggle数据集
    try:
        kaggle_data = load_json("mbti_dataset_cleaned.json")
        print(f"Kaggle数据集加载完成，共{len(kaggle_data)}条记录")
        
        # 选择示例
        kaggle_examples = select_examples(kaggle_data, "Kaggle")
        print(f"Kaggle数据集选择了{len(kaggle_examples)}个MBTI类型的示例")
        
        # 保存示例
        with open("kaggle_examples.json", "w", encoding="utf-8") as f:
            json.dump(kaggle_examples, f, indent=4, ensure_ascii=False)
        print("Kaggle示例已保存到kaggle_examples.json")
        
    except Exception as e:
        print(f"处理Kaggle数据集时出错：{e}")
    
    # Pandora数据集
    try:
        pandora_data = load_json("pandora_clean_sampled.json")
        print(f"Pandora数据集加载完成，共{len(pandora_data)}条记录")
        
        # 选择示例
        pandora_examples = select_examples(pandora_data, "Pandora")
        print(f"Pandora数据集选择了{len(pandora_examples)}个MBTI类型的示例")
        
        # 保存示例
        with open("pandora_examples.json", "w", encoding="utf-8") as f:
            json.dump(pandora_examples, f, indent=4, ensure_ascii=False)
        print("Pandora示例已保存到pandora_examples.json")
        
    except Exception as e:
        print(f"处理Pandora数据集时出错：{e}")

if __name__ == "__main__":
    main()