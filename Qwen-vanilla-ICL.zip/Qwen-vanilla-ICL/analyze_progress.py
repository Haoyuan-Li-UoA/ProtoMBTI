import json
import os

def analyze_progress(progress_file):
    """分析进度文件并计算当前的准确率"""
    if not os.path.exists(progress_file):
        print(f"进度文件不存在: {progress_file}")
        return
    
    # 读取进度文件
    with open(progress_file, 'r', encoding='utf-8') as f:
        progress = json.load(f)
    
    print(f"\n=== 进度分析 ===")
    print(f"已处理数据量: {progress['index'] + 1} 条")
    print(f"总处理进度: {progress['index'] + 1} / {len(progress['processed_data'])}")
    
    # 提取成功处理的数据
    successful_data = [item for item in progress['processed_data'] if item.get('status') == 'success']
    skipped_data = [item for item in progress['processed_data'] if item.get('status') == 'skipped']
    
    print(f"成功处理: {len(successful_data)} 条")
    print(f"跳过处理: {len(skipped_data)} 条")
    
    if not successful_data:
        print("没有成功处理的数据")
        return
    
    # 计算准确率
    def calculate_accuracy(predictions, ground_truths):
        dimension_correct = {
            "E/I": 0,
            "S/N": 0, 
            "T/F": 0,
            "J/P": 0
        }
        
        total = len(predictions)
        
        for pred, gt in zip(predictions, ground_truths):
            # 验证预测结果是否有效
            if len(pred) != 4:
                continue
            
            # 计算准确率
            if pred[0] == gt["E/I"]:
                dimension_correct["E/I"] += 1
            if pred[1] == gt["S/N"]:
                dimension_correct["S/N"] += 1
            if pred[2] == gt["T/F"]:
                dimension_correct["T/F"] += 1
            if pred[3] == gt["J/P"]:
                dimension_correct["J/P"] += 1
        
        # 计算各维度准确率
        accuracy = {}
        for dimension, correct in dimension_correct.items():
            accuracy[dimension] = correct / total if total > 0 else 0
        
        return accuracy
    
    # 准备预测和真实值
    predictions = [item['predicted_mbti'] for item in successful_data]
    ground_truths = [item['ground_truth'] for item in successful_data]
    
    # 计算准确率
    accuracy = calculate_accuracy(predictions, ground_truths)
    
    # 显示结果
    print(f"\n=== 当前准确率结果 ===")
    for dimension, acc in accuracy.items():
        print(f"  {dimension}: {acc:.4f} ({int(acc*100)}%)")
    
    # 计算MBTI类型整体准确率
    correct_types = sum(1 for pred, gt in zip(predictions, ground_truths) 
                      if pred == f"{gt['E/I']}{gt['S/N']}{gt['T/F']}{gt['J/P']}")
    type_accuracy = correct_types / len(predictions) if predictions else 0
    print(f"  MBTI类型整体准确率: {type_accuracy:.4f} ({int(type_accuracy*100)}%)")
    
    # 显示最新处理的几条数据
    print(f"\n=== 最新处理的5条数据 ===")
    latest_data = successful_data[-5:]
    for i, item in enumerate(reversed(latest_data), 1):
        print(f"\n第 {len(successful_data) - i + 1} 条数据:")
        print(f"  真实MBTI: {item['item']['mbti']}")
        print(f"  预测MBTI: {item['predicted_mbti']}")
        print(f"  预测结果: {'✅ 正确' if item['predicted_mbti'] == item['item']['mbti'] else '❌ 错误'}")

if __name__ == "__main__":
    # 分析pandora_clean的进度
    analyze_progress("pandora_clean_icl_progress.json")
    
    # 检查是否有其他进度文件
    other_files = [f for f in os.listdir(".") if f.endswith("_icl_progress.json") and f != "pandora_clean_icl_progress.json"]
    for file in other_files:
        print(f"\n\n=== 分析 {file} ===")
        analyze_progress(file)
