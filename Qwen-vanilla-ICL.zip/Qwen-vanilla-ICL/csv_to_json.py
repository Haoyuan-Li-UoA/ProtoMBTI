import csv
import json
import os

def convert_csv_to_json(csv_file_path, json_file_path):
    # 读取CSV文件
    data = []
    with open(csv_file_path, 'r', encoding='utf-8') as csv_file:
        csv_reader = csv.DictReader(csv_file)
        for row in csv_reader:
            data.append(row)
    
    # 写入JSON文件
    with open(json_file_path, 'w', encoding='utf-8') as json_file:
        json.dump(data, json_file, indent=4, ensure_ascii=False)
    
    print(f"转换完成！CSV文件 '{csv_file_path}' 已成功转换为JSON文件 '{json_file_path}'")
    print(f"共转换了 {len(data)} 条记录")

if __name__ == "__main__":
    # 定义文件路径
    csv_file = "mbti_dataset_cleaned.csv"
    json_file = "mbti_dataset_cleaned.json"
    
    # 检查CSV文件是否存在
    if not os.path.exists(csv_file):
        print(f"错误：CSV文件 '{csv_file}' 不存在")
        exit(1)
    
    # 执行转换
    convert_csv_to_json(csv_file, json_file)
