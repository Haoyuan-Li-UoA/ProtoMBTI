import pandas as pd
import re

def clean_post_text(post_text):
    """清理帖子文本中的特殊符号、链接和分隔符"""
    if not post_text:
        return ""
    
    # 处理|||分隔符 - 只保留第一个帖子内容
    if "|||" in post_text:
        post_text = post_text.split("|||")[0]
    
    # 移除网址链接（匹配http/https开头的链接）
    post_text = re.sub(r'https?://[\w\-]+(\.[\w\-]+)+([\w\-\.,@?^=%&:/~\+#]*[\w\-\@?^=%&/~\+#])?', '', post_text)
    
    # 移除_____等下划线序列（3个或以上下划线）
    post_text = re.sub(r'_{3,}', '', post_text)
    
    # 移除多余的空格和换行符
    post_text = re.sub(r'\s+', ' ', post_text).strip()
    
    # 移除首尾的单引号或反引号
    post_text = post_text.strip("'`")
    
    return post_text

def main():
    """主函数，执行数据清理流程"""
    print("开始清理MBTI数据集...")
    
    # 读取原始数据
    input_file = "mbti_dataset_icl.csv"
    try:
        df = pd.read_csv(input_file)
        print(f"成功读取数据，共{len(df)}行")
    except Exception as e:
        print(f"读取文件失败：{e}")
        return
    
    # 检查列名
    print(f"数据列名：{list(df.columns)}")
    
    # 确保存在post列
    if 'post' not in df.columns:
        print("错误：数据缺少'post'列")
        return
    
    # 应用清理函数
    print("正在清理post列内容...")
    df['cleaned_post'] = df['post'].apply(clean_post_text)
    
    # 移除空的清理后内容
    initial_count = len(df)
    df = df[df['cleaned_post'].str.len() > 0]
    removed_count = initial_count - len(df)
    print(f"移除了{removed_count}条空内容的记录")
    
    # 保存清理后的数据
    output_file = "mbti_dataset_cleaned.csv"
    try:
        df.to_csv(output_file, index=False)
        print(f"清理后的数据已保存到{output_file}")
    except Exception as e:
        print(f"保存文件失败：{e}")
        return
    
    # 显示清理前后的对比
    print("\n清理前后对比（前5条）：")
    for i in range(min(5, len(df))):
        print(f"\n原始文本：{df['post'].iloc[i][:100]}...")
        print(f"清理后：{df['cleaned_post'].iloc[i][:100]}...")
    
    print(f"\n数据清理完成！共处理{len(df)}条有效记录")

if __name__ == "__main__":
    main()