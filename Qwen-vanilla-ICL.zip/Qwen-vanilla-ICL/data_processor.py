import pandas as pd
import json
import os

def load_csv_data(file_path):
    """加载CSV文件数据"""
    if not os.path.exists(file_path):
        print(f"文件不存在：{file_path}")
        return None
    
    try:
        data = pd.read_csv(file_path)
        print(f"成功加载CSV文件：{file_path}")
        print(f"数据行数：{len(data)}")
        print(f"数据列名：{list(data.columns)}")
        return data
    except Exception as e:
        print(f"加载CSV文件失败：{e}")
        return None

def save_csv_data(data, file_path):
    """保存数据到CSV文件"""
    try:
        data.to_csv(file_path, index=False)
        print(f"成功保存数据到CSV文件：{file_path}")
        return True
    except Exception as e:
        print(f"保存CSV文件失败：{e}")
        return False

def load_json_data(file_path):
    """加载JSON文件数据"""
    if not os.path.exists(file_path):
        print(f"文件不存在：{file_path}")
        return None
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        print(f"成功加载JSON文件：{file_path}")
        if isinstance(data, list):
            print(f"数据条数：{len(data)}")
        return data
    except Exception as e:
        print(f"加载JSON文件失败：{e}")
        return None

def save_json_data(data, file_path, indent=4):
    """保存数据到JSON文件"""
    try:
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=indent)
        print(f"成功保存数据到JSON文件：{file_path}")
        return True
    except Exception as e:
        print(f"保存JSON文件失败：{e}")
        return False

def process_mbti_data(input_file, output_file):
    """处理MBTI数据文件的示例函数"""
    # 根据文件扩展名选择加载方式
    if input_file.endswith('.csv'):
        data = load_csv_data(input_file)
        if data is None:
            return False
        
        # 示例：只保留需要的列
        if 'post' in data.columns and 'mbti' in data.columns:
            processed_data = data[['post', 'mbti']]
            
            # 保存为JSON格式
            if output_file.endswith('.json'):
                # 转换为字典列表
                json_data = processed_data.to_dict('records')
                return save_json_data(json_data, output_file)
            # 保存为CSV格式
            elif output_file.endswith('.csv'):
                return save_csv_data(processed_data, output_file)
            else:
                print("不支持的输出文件格式")
                return False
        else:
            print("CSV文件缺少必要的列（post或mbti）")
            return False
    
    elif input_file.endswith('.json'):
        data = load_json_data(input_file)
        if data is None:
            return False
        
        # 示例：转换为DataFrame进行处理
        df = pd.DataFrame(data)
        
        # 保存为CSV格式
        if output_file.endswith('.csv'):
            return save_csv_data(df, output_file)
        # 保存为JSON格式
        elif output_file.endswith('.json'):
            return save_json_data(data, output_file)
        else:
            print("不支持的输出文件格式")
            return False
    
    else:
        print("不支持的输入文件格式")
        return False

def main():
    """主函数，展示数据处理功能"""
    print("数据处理工具示例")
    print("支持CSV和JSON文件的加载、保存和转换")
    print("=" * 50)
    
    # 示例使用说明
    print("\n示例1：将CSV文件转换为JSON文件")
    print("process_mbti_data('input.csv', 'output.json')")
    
    print("\n示例2：将JSON文件转换为CSV文件")
    print("process_mbti_data('input.json', 'output.csv')")
    
    print("\n示例3：加载CSV文件并查看数据")
    print("data = load_csv_data('data.csv')")
    print("print(data.head())")

if __name__ == "__main__":
    main()